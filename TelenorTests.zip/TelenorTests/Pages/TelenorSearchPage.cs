using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

namespace SeleniumWebDriverTests.Pages
{
    public class TelenorSearchPage
    {
        private readonly IWebDriver driver;
        private readonly WebDriverWait wait;

        public TelenorSearchPage(IWebDriver driver)
        {
            this.driver = driver;
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
        }

        private By SearchInput => By.XPath("//*[@class='address-search-input__wrapper__input w-100 border border-1 bg-tertiary text-primary fw-medium font-melon']");
        private By Suggestion(string address) =>
            By.XPath("//li[contains(@class, 'address-search-input__address-list__option') and normalize-space(text())='" + address.ToUpper() + "']");
        private By Dropdown => By.Id("tnid-1-select");
        private By GridItemHeading => By.CssSelector("[data-test='grid-item-heading']");

        public void SearchAddress(string address)
        {
            var input = wait.Until(ExpectedConditions.ElementToBeClickable(SearchInput));
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView({block: 'center'});", input);
            input.SendKeys(address);

            var suggestion = wait.Until(ExpectedConditions.ElementIsVisible(
                By.XPath("//li[contains(@class, 'address-search-input__address-list__option') and translate(normalize-space(text()), 'abcdefghijklmnopqrstuvwxyz', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ')='" + address.ToUpper() + "']")));
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView({block: 'center'});", suggestion);
            suggestion.Click();
        }

        public void SelectDropdownOption()
        {
            var dropdown = wait.Until(ExpectedConditions.ElementToBeClickable(Dropdown));
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView({block: 'center'});", dropdown);
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", dropdown);
            dropdown.SendKeys(Keys.Down);
        }

        public string GetGridItemHeadingText()
        {
            var heading = wait.Until(ExpectedConditions.ElementIsVisible(GridItemHeading));
            return heading.Text;
        }
    }
}   