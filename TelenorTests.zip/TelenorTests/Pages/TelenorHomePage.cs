using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

namespace SeleniumWebDriverTests.Pages
{
    public class TelenorHomePage
    {
        private readonly IWebDriver driver;
        private readonly WebDriverWait wait;

        public TelenorHomePage(IWebDriver driver)
        {
            this.driver = driver;
            wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
        }

        private By AcceptCookiesButton => By.XPath("//*[contains(text(),'Godk�nn alla cookies')]");
        private By HandlaElement => By.XPath("//*[contains(text(),'Handla')]");
        private By BredbandElement => By.XPath("//nav[not(ancestor::footer)]//a[contains(text(),'Bredband')]");

        public void AcceptCookies()
        {
            var button = wait.Until(ExpectedConditions.ElementToBeClickable(AcceptCookiesButton));
            button.Click();
        }

        public void ClickHandla()
        {
            var handla = driver.FindElement(HandlaElement);
            handla.Click();
        }

        public void ClickBredband()
        {
            var bredband = wait.Until(ExpectedConditions.ElementToBeClickable(BredbandElement));
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView({block: 'center'});", bredband);
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", bredband);
        }
    }
}   